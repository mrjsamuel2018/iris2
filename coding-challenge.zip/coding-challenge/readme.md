open command prompt/
cd iris2/ -OR- wherever user has extracted the zip
http-server    (if you dont have http-server, install it using npm install -g http-server. Or you can use any other servers like lite-server, etc.)