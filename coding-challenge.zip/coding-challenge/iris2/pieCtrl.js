'use strict';
angular
    .module('myApp')
    .controller('pieCtrl', ['$scope', function ($scope){
      $scope.title = 'Chart page';
    }]);