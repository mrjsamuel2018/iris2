'use strict';
angular
    .module('myApp')
    .controller('charttwoCtrl', ['$scope', function ($scope){
      $scope.title = 'weatherman2@company.com';
    }]);    