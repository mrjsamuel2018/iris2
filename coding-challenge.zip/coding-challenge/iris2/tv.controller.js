'use strict';
angular
    .module('myApp')
    .controller('tvCtrl', ['$scope', function ($scope){
      $scope.title = 'TV';
    }]);