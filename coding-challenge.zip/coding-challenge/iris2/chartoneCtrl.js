'use strict';
angular
    .module('myApp')
    .controller('chartoneCtrl', ['$scope', function ($scope){
      $scope.title = 'weatherman1@company.com';
    }]);